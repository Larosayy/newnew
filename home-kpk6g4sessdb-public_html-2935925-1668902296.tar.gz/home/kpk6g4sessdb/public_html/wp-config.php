<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings ** //
/** The name of the database for WordPress */
define( 'DB_NAME', "i9072167_wp1" );

/** MySQL database username */
define( 'DB_USER', "i9072167_wp1" );

/** MySQL database password */
define( 'DB_PASSWORD', "T.fvNVKX0Uut0MiNN3E75" );

/** MySQL hostname */
define( 'DB_HOST', "localhost" );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '_?<XAI+#Qv-}o+cg9@.!n.FjJ/v{cek75E72w+W}v=3D.@ m?{mzb$+TJ*)rzVs$');
define('SECURE_AUTH_KEY',  'KW;5W0]j:/5Uj(&o0OH&rcXs%Z,J1NT< W9<,]:!L^`D F>#Klq/*m`nSCK+Ec3B');
define('LOGGED_IN_KEY',    '[h(bkVV^.!,7r= +5p)U|{>tHD+oa1=f(A `c<_+Tbz(*lc#x~4`Y9Y:70c02Wg&');
define('NONCE_KEY',        'q)l;v[FK(2APuEVrMHPwuHuYwM 9;aVupc_0wa]~*7A6{MhoxTQWx<c.+1k}6k2 ');
define('AUTH_SALT',        'mhM1}9H|G!~R5eK|rPoDNc{u!G<:5!9*U@%Ryu?sl_NV,5]q;9D~,qBwRM2 o0| ');
define('SECURE_AUTH_SALT', 'WI=B})Z*adz`N<8:&HT$5pOM#IkAWMuK>^AAw~M]qV~erD[_3fyP=nsiDH[;L~-0');
define('LOGGED_IN_SALT',   'ta~u5plcpw07_5pa1?2MrD]|)Kq~Rp#nidi@i8=l5FC2w^~EJi|zEiiEOLLia(U~');
define('NONCE_SALT',       '<:S^A-^L$q)sc+m sU-%l4*/QfKp1M`>-(+-Hh~O-T{5)|m{r{k=6`:*L_05;wWx');


/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) )
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
